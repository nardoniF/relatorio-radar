from __future__ import annotations

import json
import re
import shutil
import unicodedata
from pathlib import Path

HOME_APP = Path.home() / "Documents" / "Assistente Juridico"
PROCESSOS = HOME_APP / "Processos"
CONFIG = HOME_APP / "config.json"

# Groq retirou llama-3.3-70b-versatile em ago/2026 — usar modelos atuais.
DEFAULT_CONFIG = {
    "provider": "groq",
    "provider_label": "Groq (gratuito)",
    "api_key": "",
    # 20B: melhor margem de TPM no plano gratuito para processo grande
    "model": "openai/gpt-oss-20b",
    "base_url": "https://api.groq.com/openai/v1",
    # False = envio inteligente (não sobe PDF/texto inteiro na API)
    "enviar_tudo": False,
}

# Modelos antigos / inadequados no free → 20B (120B estoura TPM em PDF grande).
LEGACY_MODELS = {
    "llama-3.3-70b-versatile": "openai/gpt-oss-20b",
    "llama-3.1-70b-versatile": "openai/gpt-oss-20b",
    "llama-3.1-8b-instant": "openai/gpt-oss-20b",
    "llama3-70b-8192": "openai/gpt-oss-20b",
    "llama3-8b-8192": "openai/gpt-oss-20b",
    "mixtral-8x7b-32768": "openai/gpt-oss-20b",
    "gemma2-9b-it": "openai/gpt-oss-20b",
    # 120B no plano free quebra processo grande (TPM 8k) — força 20B
    "openai/gpt-oss-120b": "openai/gpt-oss-20b",
    "gpt-oss-120b": "openai/gpt-oss-20b",
}

PRESETS = {
    "groq_free": {
        "provider": "groq",
        "provider_label": "Groq — gratuito 20B (recomendado p/ PDF grande)",
        "model": "openai/gpt-oss-20b",
        "base_url": "https://api.groq.com/openai/v1",
        "custo": "Grátis (com limites diários de uso)",
        "nota": "PDF fica no PC; a API só recebe trechos (envio inteligente).",
    },
    "groq_quality": {
        "provider": "groq",
        "provider_label": "Groq — 120B (NÃO use em PDF grande no free)",
        "model": "openai/gpt-oss-20b",  # forçado: 120B free quebra TPM
        "base_url": "https://api.groq.com/openai/v1",
        "custo": "Grátis — redirecionado para 20B",
        "nota": "120B free estoura em processo grande; o sistema usa 20B.",
    },
    "groq_fast": {
        "provider": "groq",
        "provider_label": "Groq — rápido (20B)",
        "model": "openai/gpt-oss-20b",
        "base_url": "https://api.groq.com/openai/v1",
        "custo": "Grátis (limites diários)",
        "nota": "Alias do gratuito 20B.",
    },
    "google_flash": {
        "provider": "google",
        "provider_label": "Google Gemini Flash (pago / free limitado)",
        "model": "gemini-2.5-flash",
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
        "custo": "Free tier limitado ou pago conforme uso",
        "nota": "Só se ainda tiver conta Gemini ativa.",
    },
    "google_pro": {
        "provider": "google",
        "provider_label": "Google Gemini Pro (pago)",
        "model": "gemini-2.5-pro",
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
        "custo": "Pago conforme uso",
        "nota": "Melhor qualidade, precisa faturamento.",
    },
    "google_lite": {
        "provider": "google",
        "provider_label": "Google Gemini Flash-Lite",
        "model": "gemini-2.5-flash-lite",
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
        "custo": "Barato / free limitado",
        "nota": "Só rascunho simples.",
    },
    "openai_mini": {
        "provider": "openai",
        "provider_label": "OpenAI GPT-4.1 mini (pago — recomendado p/ processo grande)",
        "model": "gpt-4.1-mini",
        "base_url": "https://api.openai.com/v1",
        "custo": "Pago por uso (API). ChatGPT Plus NÃO serve — precisa chave sk-...",
        "nota": "Crie chave em platform.openai.com/api-keys (conta com crédito). Envia extrato completo.",
    },
    "openai_41": {
        "provider": "openai",
        "provider_label": "OpenAI GPT-4.1 (pago — melhor qualidade)",
        "model": "gpt-4.1",
        "base_url": "https://api.openai.com/v1",
        "custo": "Pago por uso (API). Mais caro que o mini.",
        "nota": "Melhor para peça complexa. Chave sk-... em platform.openai.com/api-keys.",
    },
    "openai_4o": {
        "provider": "openai",
        "provider_label": "OpenAI GPT-4o (pago)",
        "model": "gpt-4o",
        "base_url": "https://api.openai.com/v1",
        "custo": "Pago por uso (API).",
        "nota": "Alternativa. ChatGPT assinado no site NÃO é a mesma coisa que a API.",
    },
}


def ensure_dirs() -> None:
    PROCESSOS.mkdir(parents=True, exist_ok=True)
    HOME_APP.mkdir(parents=True, exist_ok=True)
    if not CONFIG.exists():
        CONFIG.write_text(
            json.dumps(DEFAULT_CONFIG, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )


def _migrate_model(data: dict) -> tuple[dict, bool]:
    """Troca modelos Groq aposentados / 120B free; retorna (data, mudou)."""
    changed = False
    model = (data.get("model") or data.get("openai_model") or "").strip()
    base = (data.get("base_url") or "").lower()
    provider = (data.get("provider") or "").lower()
    if model in LEGACY_MODELS:
        data["model"] = LEGACY_MODELS[model]
        changed = True
        model = data["model"]
    # Qualquer *120b* no Groq free → 20B (TPM 8k não aguenta PDF grande)
    if ("groq.com" in base or provider == "groq") and "120b" in model.lower():
        data["model"] = "openai/gpt-oss-20b"
        data["provider"] = "groq"
        data["provider_label"] = "Groq — gratuito 20B (auto)"
        data["base_url"] = "https://api.groq.com/openai/v1"
        data["enviar_tudo"] = False
        changed = True
    if (provider == "groq" or "groq.com" in base) and not (data.get("model") or "").strip():
        data["model"] = DEFAULT_CONFIG["model"]
        changed = True
    return data, changed


def _read_config_raw() -> dict:
    ensure_dirs()
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    if not isinstance(data, dict):
        data = {}
    # migra config antiga
    if data.get("openai_api_key") and not data.get("api_key"):
        data["api_key"] = data["openai_api_key"]
    if data.get("openai_model") and not data.get("model"):
        data["model"] = data["openai_model"]
    return data


def _write_config(data: dict) -> None:
    ensure_dirs()
    clean = dict(data)
    clean.pop("openai_api_key", None)
    clean.pop("openai_model", None)
    clean.pop("openai_base_url", None)
    CONFIG.write_text(json.dumps(clean, indent=2, ensure_ascii=False), encoding="utf-8")


def load_config() -> dict:
    data = _read_config_raw()
    data, changed = _migrate_model(data)
    if changed:
        try:
            _write_config(data)
        except Exception:
            pass
    return data


def save_config(data: dict) -> None:
    current = _read_config_raw()
    current.update(data)
    current, _ = _migrate_model(current)
    _write_config(current)


def slug(text: str, max_len: int = 60) -> str:
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_")
    return (text or "parte")[:max_len]


def folder_name(reclamante: str, reclamado: str, numero: str) -> str:
    n = re.sub(r"[^\d\.\-]", "", numero or "sem-numero")
    return f"{slug(reclamante)}_x_{slug(reclamado)}_{n}"


def copy_into_case(src: Path, meta: dict) -> Path:
    ensure_dirs()
    dest_dir = PROCESSOS / folder_name(
        meta.get("reclamante") or "Reclamante",
        meta.get("reclamado") or "Reclamado",
        meta.get("numero") or "processo",
    )
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_pdf = dest_dir / "processo.pdf"
    if src.resolve() != dest_pdf.resolve():
        shutil.copy2(src, dest_pdf)
    (dest_dir / "meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return dest_dir


def list_cases() -> list[dict]:
    ensure_dirs()
    out = []
    for d in sorted(PROCESSOS.iterdir(), reverse=True):
        if not d.is_dir():
            continue
        meta_path = d / "meta.json"
        meta = {}
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception:
                meta = {}
        docs = sorted(
            p.name
            for p in d.iterdir()
            if p.is_file() and p.suffix.lower() in {".docx", ".pdf"} and p.name != "processo.pdf"
        )
        has_processo = (d / "processo.pdf").exists()
        prompts_n = 0
        pp = d / "prompts_caso.json"
        if pp.exists():
            try:
                pdata = json.loads(pp.read_text(encoding="utf-8"))
                prompts_n = len(pdata.get("geral") or [])
            except Exception:
                prompts_n = 0
        out.append(
            {
                "id": d.name,
                "path": str(d),
                "meta": meta,
                "docx": [x for x in docs if x.endswith(".docx")],
                "pdfs": [x for x in docs if x.endswith(".pdf")],
                "arquivos": docs,
                "tem_processo": has_processo,
                "prompts_salvos": prompts_n,
            }
        )
    return out


def case_dir(case_id: str) -> Path:
    d = (PROCESSOS / case_id).resolve()
    if PROCESSOS.resolve() not in d.parents and d != PROCESSOS.resolve():
        raise ValueError("pasta invalida")
    if not d.is_dir():
        raise FileNotFoundError(case_id)
    return d
